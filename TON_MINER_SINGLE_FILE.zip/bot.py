import asyncio, json, os, time, uuid
from pathlib import Path
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
    LabeledPrice, PreCheckoutQuery
)

load_dotenv()

# ============================================================
# CONFIG
# ============================================================
BOT_TOKEN = os.getenv("BOT_TOKEN", "PUT_BOT_TOKEN_HERE")
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))

DB_FILE = Path("ton_miner_data.json")

if BOT_TOKEN == "PUT_BOT_TOKEN_HERE":
    raise RuntimeError("Set BOT_TOKEN in your environment/.env file.")

# ============================================================
# DATABASE
# ============================================================
DEFAULT_DB = {
    "settings": {
        "required_referrals": 5,
        "minimum_withdrawal": 5.0,
        "machine_required_for_withdrawal": True,
        "required_channels": []
    },
    "machines": [
        {"id": "free", "name": "FREE MINER", "stars": 0, "hours_per_ton": 20.0},
        {"id": "m50", "name": "TURBO MINER", "stars": 50, "hours_per_ton": 10.0},
        {"id": "m100", "name": "HYPER MINER", "stars": 100, "hours_per_ton": 5.0},
        {"id": "m200", "name": "ULTRA MINER", "stars": 200, "hours_per_ton": 1.25}
    ],
    "earn_tasks": [],
    "users": {},
    "withdrawals": {},
    "transactions": [],
    "stars_payments": {}
}

def load_db():
    if not DB_FILE.exists():
        DB_FILE.write_text(json.dumps(DEFAULT_DB, indent=2), encoding="utf-8")
        return json.loads(json.dumps(DEFAULT_DB))
    try:
        data = json.loads(DB_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = json.loads(json.dumps(DEFAULT_DB))

    for key, value in DEFAULT_DB.items():
        data.setdefault(key, value)
    for key, value in DEFAULT_DB["settings"].items():
        data["settings"].setdefault(key, value)
    return data

db = load_db()

def save_db():
    temp = DB_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(db, indent=2), encoding="utf-8")
    temp.replace(DB_FILE)

def get_user(uid, username=None, first_name=None):
    key = str(uid)
    if key not in db["users"]:
        db["users"][key] = {
            "id": uid,
            "username": username or "",
            "first_name": first_name or "",
            "balance": 0.0,
            "uncollected": 0.0,
            "machine_id": "free",
            "machine_started": time.time(),
            "wallet": "",
            "channel_verified": False,
            "referrer": None,
            "referrals": [],
            "valid_referrals": [],
            "earn_done": [],
            "withdrawal_id": None
        }
        save_db()

    u = db["users"][key]
    if username is not None:
        u["username"] = username
    if first_name is not None:
        u["first_name"] = first_name
    u.setdefault("uncollected", 0.0)
    return u

def machine(mid):
    return next((m for m in db["machines"] if m["id"] == mid), None)

def fmt(n):
    return f"{float(n):.6f}".rstrip("0").rstrip(".") or "0"

def progress_bar(percent, size=18):
    percent = max(0.0, min(100.0, percent))
    filled = int(round((percent / 100) * size))
    return "▰" * filled + "▱" * (size - filled)

def accrue_mining(uid):
    """
    Mining is simulated internally according to the configured machine rate.
    It accrues continuously into an UNCOLLECTED amount.
    The user must press COLLECT to move it to available balance.
    """
    u = get_user(uid)
    m = machine(u["machine_id"]) or machine("free")

    now = time.time()
    started = float(u.get("machine_started", now))
    elapsed = max(0.0, now - started)

    hours = float(m["hours_per_ton"])
    mined = elapsed / (hours * 3600.0)

    if mined > 0:
        u["uncollected"] += mined
        u["machine_started"] = now
        save_db()

    return mined

def mining_state(u):
    m = machine(u["machine_id"]) or machine("free")
    cycle = float(m["hours_per_ton"]) * 3600.0

    # Current cycle progress is represented by elapsed time since last accrual.
    elapsed = max(0.0, time.time() - float(u.get("machine_started", time.time())))
    percent = min(100.0, elapsed / cycle * 100.0)
    remaining = max(0, int(cycle - elapsed))

    hours = remaining // 3600
    minutes = (remaining % 3600) // 60
    seconds = remaining % 60

    return m, elapsed, percent, remaining, f"{hours:02d}:{minutes:02d}:{seconds:02d}"

# ============================================================
# KEYBOARDS
# ============================================================
def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⛏️ MINING", callback_data="mining"),
            InlineKeyboardButton(text="🖥️ MACHINES", callback_data="machines")
        ],
        [
            InlineKeyboardButton(text="💎 BALANCE", callback_data="balance"),
            InlineKeyboardButton(text="👥 REFERRALS", callback_data="referrals")
        ],
        [
            InlineKeyboardButton(text="🎯 EARN", callback_data="earn"),
            InlineKeyboardButton(text="👛 WALLET", callback_data="wallet")
        ],
        [
            InlineKeyboardButton(text="💸 WITHDRAW", callback_data="withdraw"),
            InlineKeyboardButton(text="📜 HISTORY", callback_data="history")
        ],
        [InlineKeyboardButton(text="📊 PROFILE", callback_data="profile")]
    ])

def back_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↩️ MAIN MENU", callback_data="home")]
    ])

def mining_keyboard(has_collect=True):
    rows = [
        [
            InlineKeyboardButton(text="🔄 REFRESH", callback_data="mining"),
            InlineKeyboardButton(text="💎 BALANCE", callback_data="balance")
        ]
    ]
    if has_collect:
        rows.append([
            InlineKeyboardButton(text="💰 COLLECT", callback_data="collect")
        ])
    rows.append([
        InlineKeyboardButton(text="🖥️ MACHINES", callback_data="machines")
    ])
    rows.append([
        InlineKeyboardButton(text="↩️ MAIN MENU", callback_data="home")
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def admin_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="📊 STATS", callback_data="adm:stats"),
            InlineKeyboardButton(text="💸 WITHDRAWALS", callback_data="adm:withdrawals")
        ],
        [
            InlineKeyboardButton(text="📢 BROADCAST", callback_data="adm:broadcast"),
            InlineKeyboardButton(text="📢 CHANNELS", callback_data="adm:channels")
        ],
        [
            InlineKeyboardButton(text="🎯 EARN TASKS", callback_data="adm:tasks"),
            InlineKeyboardButton(text="🖥️ MACHINES", callback_data="adm:machines")
        ],
        [InlineKeyboardButton(text="⚙️ SETTINGS", callback_data="adm:settings")]
    ])

# ============================================================
# TELEGRAM HELPERS
# ============================================================
async def is_member(uid, chat_id):
    try:
        member = await bot.get_chat_member(chat_id, uid)
        return member.status not in ("left", "kicked")
    except Exception:
        return False

async def required_channels_ok(uid):
    for ch in db["settings"]["required_channels"]:
        if not await is_member(uid, ch["chat_id"]):
            return False
    return True

def required_channels_keyboard():
    rows = []
    for ch in db["settings"]["required_channels"]:
        rows.append([
            InlineKeyboardButton(text=f"📢 {ch['name']}", url=ch["url"])
        ])
    rows.append([
        InlineKeyboardButton(text="✅ VERIFY & CONTINUE", callback_data="verify")
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)

async def validate_user(uid):
    u = get_user(uid)
    ok = await required_channels_ok(uid)

    if not ok:
        return False

    u["channel_verified"] = True

    # IMPORTANT:
    # Referral becomes valid only when the invited user has BOTH:
    # 1) completed required channel verification
    # 2) connected a wallet.
    if u["wallet"] and u["referrer"]:
        ref = get_user(u["referrer"])
        if uid not in ref["valid_referrals"]:
            ref["valid_referrals"].append(uid)
            try:
                await bot.send_message(
                    ref["id"],
                    "🎉 <b>REFERRAL VERIFIED</b>\n\n"
                    "Your invited user completed verification and connected a wallet."
                )
            except Exception:
                pass

    save_db()
    return True

# ============================================================
# BOT
# ============================================================
bot = Bot(
    BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)
dp = Dispatcher()

wallet_wait = set()
broadcast_wait = set()

# ============================================================
# USER START / DASHBOARD
# ============================================================
async def send_dashboard(message: Message):
    u = get_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name
    )

    await validate_user(u["id"])
    m = machine(u["machine_id"]) or machine("free")

    await message.answer(
        "<b>⚡ TON MINER</b>\n"
        "<i>DECENTRALIZED MINING SIMULATOR</i>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"💎 AVAILABLE\n"
        f"<b>{fmt(u['balance'])} TON</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"⛏️ Active Machine: <b>{m['name']}</b>\n"
        f"⚡ Production: <b>1 TON / {m['hours_per_ton']} HOURS</b>\n\n"
        f"👥 Referrals: <b>{len(u['valid_referrals'])}/{db['settings']['required_referrals']}</b>\n"
        f"👛 Wallet: <b>{'CONNECTED ✅' if u['wallet'] else 'NOT CONNECTED ❌'}</b>\n\n"
        "<i>Use MINING to monitor your active cycle.</i>",
        reply_markup=main_keyboard()
    )

@dp.message(CommandStart())
async def start(message: Message):
    u = get_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name
    )

    parts = (message.text or "").split(maxsplit=1)

    if len(parts) == 2 and parts[1].startswith("ref_"):
        try:
            ref_id = int(parts[1][4:])
            if ref_id != u["id"] and not u["referrer"]:
                u["referrer"] = ref_id
                ref = get_user(ref_id)
                if u["id"] not in ref["referrals"]:
                    ref["referrals"].append(u["id"])
                save_db()
        except ValueError:
            pass

    if db["settings"]["required_channels"] and not await required_channels_ok(u["id"]):
        await message.answer(
            "<b>🔐 ACCESS VERIFICATION</b>\n\n"
            "Join all required channels/groups to unlock TON MINER.\n\n"
            "After joining everything, press <b>VERIFY & CONTINUE</b>.",
            reply_markup=required_channels_keyboard()
        )
        return

    await validate_user(u["id"])
    await send_dashboard(message)

@dp.callback_query(F.data == "verify")
async def verify_callback(c: CallbackQuery):
    if not await validate_user(c.from_user.id):
        await c.answer("❌ Please join every required channel first.", show_alert=True)
        return

    await c.message.edit_text(
        "<b>✅ VERIFICATION COMPLETE</b>\n\n"
        "Your account is unlocked.",
        reply_markup=back_keyboard()
    )
    await c.answer()

@dp.callback_query(F.data == "home")
async def home_callback(c: CallbackQuery):
    await c.message.delete()
    await send_dashboard(c.message)
    await c.answer()

# ============================================================
# MINING — REFRESH + COLLECT
# ============================================================
@dp.callback_query(F.data == "mining")
async def mining_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)

    # First move elapsed production into the uncollected bucket.
    accrue_mining(u["id"])

    m, elapsed, percent, remaining, timer = mining_state(u)
    uncollected = float(u["uncollected"])

    # How long the current machine has been active in a readable form.
    total_seconds = int(elapsed)
    active_h = total_seconds // 3600
    active_m = (total_seconds % 3600) // 60
    active_s = total_seconds % 60

    await c.message.edit_text(
        "<b>⛏️ MINING CORE</b>\n"
        "<i>LIVE MINING MONITOR</i>\n\n"
        "╭────────────────────────╮\n"
        f"│ 🖥️ <b>{m['name']}</b>\n"
        f"│ ⚡ <b>1 TON / {m['hours_per_ton']} HOURS</b>\n"
        "╰────────────────────────╯\n\n"
        "💎 <b>MINED & READY TO COLLECT</b>\n"
        f"<code>{fmt(uncollected)} TON</code>\n\n"
        "📈 <b>CURRENT CYCLE</b>\n"
        f"{progress_bar(percent)}  <b>{percent:.1f}%</b>\n\n"
        f"⏱️ Mining active: <b>{active_h:02d}:{active_m:02d}:{active_s:02d}</b>\n"
        f"⏳ Next cycle: <b>{timer}</b>\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Collectable: <b>{fmt(uncollected)} TON</b>\n"
        f"💎 Balance: <b>{fmt(u['balance'])} TON</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "<i>Press REFRESH to update the live mining status.</i>",
        reply_markup=mining_keyboard(uncollected > 0)
    )
    await c.answer()

@dp.callback_query(F.data == "collect")
async def collect_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    accrue_mining(u["id"])

    amount = float(u["uncollected"])

    if amount <= 0:
        await c.answer("⏳ Nothing is ready to collect yet.", show_alert=True)
        return

    u["balance"] += amount
    u["uncollected"] = 0.0

    db["transactions"].append({
        "id": uuid.uuid4().hex[:10],
        "user_id": u["id"],
        "type": "mining_collect",
        "amount": amount,
        "time": time.time()
    })
    save_db()

    await c.message.edit_text(
        "<b>💎 COLLECTION SUCCESSFUL</b>\n\n"
        f"Collected: <b>+{fmt(amount)} TON</b>\n\n"
        f"New balance: <b>{fmt(u['balance'])} TON</b>\n\n"
        "⛏️ Mining continues automatically.",
        reply_markup=mining_keyboard(False)
    )
    await c.answer("TON collected successfully.")

# ============================================================
# BALANCE / REFERRALS / WALLET / EARN
# ============================================================
@dp.callback_query(F.data == "balance")
async def balance_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    accrue_mining(u["id"])

    await c.message.edit_text(
        "<b>💎 BALANCE CENTER</b>\n\n"
        f"Available: <b>{fmt(u['balance'])} TON</b>\n"
        f"Mining ready: <b>{fmt(u['uncollected'])} TON</b>\n"
        f"Minimum withdrawal: <b>{fmt(db['settings']['minimum_withdrawal'])} TON</b>\n"
        f"Valid referrals: <b>{len(u['valid_referrals'])}/{db['settings']['required_referrals']}</b>",
        reply_markup=back_keyboard()
    )
    await c.answer()

@dp.callback_query(F.data == "referrals")
async def referrals_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    me = await bot.get_me()
    link = f"https://t.me/{me.username}?start=ref_{u['id']}"

    await c.message.edit_text(
        "<b>👥 REFERRAL NETWORK</b>\n\n"
        f"Valid referrals: <b>{len(u['valid_referrals'])}/{db['settings']['required_referrals']}</b>\n"
        f"Total invited: <b>{len(u['referrals'])}</b>\n\n"
        f"🔗 <code>{link}</code>\n\n"
        "<i>A referral becomes valid only after the invited user "
        "completes verification and connects a wallet.</i>",
        reply_markup=back_keyboard()
    )
    await c.answer()

@dp.callback_query(F.data == "wallet")
async def wallet_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    wallet_wait.add(c.from_user.id)

    await c.message.edit_text(
        "<b>👛 TON WALLET</b>\n\n"
        f"Current: <code>{u['wallet'] or 'NOT CONNECTED'}</code>\n\n"
        "Send your TON wallet address in your next message.\n\n"
        "⚠️ Never send a seed phrase or private key.",
        reply_markup=back_keyboard()
    )
    await c.answer()

@dp.callback_query(F.data == "earn")
async def earn_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    rows = []

    for task in db["earn_tasks"]:
        done = task["id"] in u["earn_done"]
        rows.append([
            InlineKeyboardButton(
                text=f"{'✅' if done else '🎯'} {task['name']} • +{fmt(task['reward'])} TON",
                callback_data=f"earn:{task['id']}"
            )
        ])

    rows.append([
        InlineKeyboardButton(text="↩️ MAIN MENU", callback_data="home")
    ])

    await c.message.edit_text(
        "<b>🎯 EARN CENTER</b>\n\n"
        "Complete channel-join tasks and receive TON.\n\n"
        "Join the channel → CHECK JOIN → reward credited.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)
    )
    await c.answer()

@dp.callback_query(F.data.startswith("earn:"))
async def earn_detail(c: CallbackQuery):
    task_id = c.data.split(":", 1)[1]
    task = next((x for x in db["earn_tasks"] if x["id"] == task_id), None)

    if not task:
        await c.answer("Task no longer exists.", show_alert=True)
        return

    u = get_user(c.from_user.id)

    await c.message.edit_text(
        "<b>🎯 CHANNEL TASK</b>\n\n"
        f"📢 Channel: <b>{task['name']}</b>\n"
        f"💎 Reward: <b>+{fmt(task['reward'])} TON</b>\n\n"
        "Join the channel, then press CHECK JOIN.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📢 JOIN CHANNEL", url=task["url"])],
            [InlineKeyboardButton(text="✅ CHECK JOIN", callback_data=f"checkearn:{task_id}")],
            [InlineKeyboardButton(text="↩️ BACK", callback_data="earn")]
        ])
    )
    await c.answer()

@dp.callback_query(F.data.startswith("checkearn:"))
async def check_earn(c: CallbackQuery):
    task_id = c.data.split(":", 1)[1]
    task = next((x for x in db["earn_tasks"] if x["id"] == task_id), None)
    u = get_user(c.from_user.id)

    if not task:
        await c.answer("Task removed.", show_alert=True)
        return

    if task_id in u["earn_done"]:
        await c.answer("Already rewarded.", show_alert=True)
        return

    if not await is_member(u["id"], task["chat_id"]):
        await c.answer("❌ Join the channel first.", show_alert=True)
        return

    reward = float(task["reward"])
    u["earn_done"].append(task_id)
    u["balance"] += reward

    db["transactions"].append({
        "id": uuid.uuid4().hex[:10],
        "user_id": u["id"],
        "type": "channel_earn",
        "amount": reward,
        "task": task_id,
        "time": time.time()
    })
    save_db()

    await c.message.edit_text(
        "<b>🎉 TASK VERIFIED</b>\n\n"
        f"Reward: <b>+{fmt(reward)} TON</b>\n"
        f"Balance: <b>{fmt(u['balance'])} TON</b>",
        reply_markup=back_keyboard()
    )
    await c.answer("Reward credited.")

# ============================================================
# MACHINES + REAL TELEGRAM STARS INVOICE
# ============================================================
@dp.callback_query(F.data == "machines")
async def machines_callback(c: CallbackQuery):
    rows = []

    for m in db["machines"]:
        price = "FREE" if m["stars"] == 0 else f"{m['stars']} ⭐"
        rows.append([
            InlineKeyboardButton(
                text=f"{m['name']} • {price}",
                callback_data=f"machine:{m['id']}"
            )
        ])

    rows.append([
        InlineKeyboardButton(text="↩️ MAIN MENU", callback_data="home")
    ])

    await c.message.edit_text(
        "<b>🖥️ MINING HARDWARE</b>\n"
        "<i>Choose your mining machine</i>\n\n"
        "🟢 FREE — 1 TON / 20 HOURS\n"
        "⭐ 50 — 1 TON / 10 HOURS\n"
        "⚡ 100 — 1 TON / 5 HOURS\n"
        "🔥 200 — 1 TON / 1.25 HOURS\n\n"
        "<i>Paid machines are purchased using Telegram Stars.</i>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)
    )
    await c.answer()

@dp.callback_query(F.data.startswith("machine:"))
async def machine_detail_callback(c: CallbackQuery):
    mid = c.data.split(":", 1)[1]
    m = machine(mid)

    if not m:
        await c.answer("Machine unavailable.", show_alert=True)
        return

    if m["stars"] == 0:
        u = get_user(c.from_user.id)
        accrue_mining(u["id"])
        u["machine_id"] = "free"
        u["machine_started"] = time.time()
        save_db()

        await c.message.edit_text(
            "<b>🟢 FREE MINER ACTIVATED</b>\n\n"
            "⚡ Production: <b>1 TON / 20 HOURS</b>\n\n"
            "⛏️ Mining cycle started.",
            reply_markup=back_keyboard()
        )
        await c.answer()
        return

    await c.message.edit_text(
        f"<b>⚡ {m['name']}</b>\n\n"
        f"⭐ Price: <b>{m['stars']} Stars</b>\n"
        f"⛏️ Production: <b>1 TON / {m['hours_per_ton']} HOURS</b>\n\n"
        "Payment is handled through Telegram Stars.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=f"⭐ BUY FOR {m['stars']} STARS",
                    callback_data=f"buy:{m['id']}"
                )
            ],
            [InlineKeyboardButton(text="↩️ BACK", callback_data="machines")]
        ])
    )
    await c.answer()

@dp.callback_query(F.data.startswith("buy:"))
async def buy_machine(c: CallbackQuery):
    mid = c.data.split(":", 1)[1]
    m = machine(mid)

    if not m or m["stars"] <= 0:
        await c.answer("Invalid machine.", show_alert=True)
        return

    payload = f"machine:{mid}:{c.from_user.id}:{uuid.uuid4().hex[:8]}"

    await bot.send_invoice(
        chat_id=c.from_user.id,
        title=m["name"],
        description=f"Mining machine — 1 TON / {m['hours_per_ton']} hours",
        payload=payload,
        currency="XTR",
        prices=[LabeledPrice(label=m["name"], amount=int(m["stars"]))]
    )
    await c.answer()

@dp.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery):
    await q.answer(ok=True)

@dp.message(F.successful_payment)
async def successful_payment(message: Message):
    payload = message.successful_payment.invoice_payload

    if not payload.startswith("machine:"):
        return

    parts = payload.split(":")
    if len(parts) < 4:
        return

    _, mid, uid, _ = parts

    if int(uid) != message.from_user.id:
        return

    m = machine(mid)
    if not m:
        return

    payment_id = message.successful_payment.telegram_payment_charge_id

    if payment_id in db["stars_payments"]:
        return

    db["stars_payments"][payment_id] = {
        "user_id": message.from_user.id,
        "machine_id": mid,
        "stars": message.successful_payment.total_amount,
        "time": time.time()
    }

    u = get_user(message.from_user.id)
    accrue_mining(u["id"])
    u["machine_id"] = mid
    u["machine_started"] = time.time()

    db["transactions"].append({
        "id": uuid.uuid4().hex[:10],
        "user_id": u["id"],
        "type": "machine_purchase",
        "amount": 0,
        "stars": message.successful_payment.total_amount,
        "machine": mid,
        "time": time.time()
    })
    save_db()

    await message.answer(
        "<b>💳 PAYMENT CONFIRMED</b>\n\n"
        f"🖥️ Machine: <b>{m['name']}</b>\n"
        f"⭐ Paid: <b>{message.successful_payment.total_amount} Stars</b>\n"
        f"⚡ Rate: <b>1 TON / {m['hours_per_ton']} HOURS</b>\n\n"
        "🟢 <b>MINING CYCLE STARTED</b>",
        reply_markup=main_keyboard()
    )

# ============================================================
# WITHDRAWAL
# ============================================================
@dp.callback_query(F.data == "withdraw")
async def withdraw_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    accrue_mining(u["id"])

    minimum = float(db["settings"]["minimum_withdrawal"])

    if u["withdrawal_id"]:
        text = (
            "<b>⏳ WITHDRAWAL IN PROGRESS</b>\n\n"
            "You already have one request waiting for admin."
        )

    elif not u["wallet"]:
        text = (
            "<b>❌ WITHDRAWAL LOCKED</b>\n\n"
            "STEP 1 — Connect your TON wallet."
        )

    elif len(u["valid_referrals"]) < int(db["settings"]["required_referrals"]):
        text = (
            "<b>❌ WITHDRAWAL LOCKED</b>\n\n"
            "STEP 2 — Referral requirement\n\n"
            f"Valid: <b>{len(u['valid_referrals'])}/{db['settings']['required_referrals']}</b>"
        )

    elif u["balance"] < minimum:
        text = (
            "<b>❌ WITHDRAWAL LOCKED</b>\n\n"
            "STEP 3 — Minimum balance\n\n"
            f"Required: <b>{fmt(minimum)} TON</b>\n"
            f"Available: <b>{fmt(u['balance'])} TON</b>"
        )

    elif db["settings"]["machine_required_for_withdrawal"] and u["machine_id"] == "free":
        text = (
            "<b>❌ WITHDRAWAL LOCKED</b>\n\n"
            "STEP 4 — Machine purchase required\n\n"
            "Purchase a paid machine with Telegram Stars, then withdrawal will unlock."
        )

    else:
        wid = uuid.uuid4().hex[:10]
        amount = float(u["balance"])

        db["withdrawals"][wid] = {
            "id": wid,
            "user_id": u["id"],
            "amount": amount,
            "wallet": u["wallet"],
            "status": "pending",
            "created": time.time()
        }

        u["withdrawal_id"] = wid
        save_db()

        text = (
            "<b>💸 WITHDRAWAL REQUEST SENT</b>\n\n"
            f"Amount: <b>{fmt(amount)} TON</b>\n"
            f"Wallet: <code>{u['wallet']}</code>\n\n"
            "Status: <b>⏳ ADMIN REVIEW</b>\n\n"
            "Please wait for your funds to arrive."
        )

        try:
            await bot.send_message(
                ADMIN_ID,
                "<b>🚨 NEW TON PAYOUT REQUEST</b>\n\n"
                f"User ID: <code>{u['id']}</code>\n"
                f"Amount: <b>{fmt(amount)} TON</b>\n"
                f"Wallet: <code>{u['wallet']}</code>\n"
                f"Request ID: <code>{wid}</code>\n\n"
                "Complete the real TON transfer externally, then mark it PAID.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="✅ APPROVE", callback_data=f"wd:approve:{wid}")],
                    [InlineKeyboardButton(text="❌ REJECT", callback_data=f"wd:reject:{wid}")],
                    [InlineKeyboardButton(text="💎 MARK PAID", callback_data=f"wd:paid:{wid}")]
                ])
            )
        except Exception:
            pass

    await c.message.edit_text(text, reply_markup=back_keyboard())
    await c.answer()

@dp.callback_query(F.data.startswith("wd:"))
async def withdrawal_admin(c: CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Admin only.", show_alert=True)
        return

    _, action, wid = c.data.split(":")
    w = db["withdrawals"].get(wid)

    if not w:
        await c.answer("Withdrawal not found.", show_alert=True)
        return

    u = get_user(w["user_id"])

    if action == "approve":
        w["status"] = "approved"
        await bot.send_message(
            u["id"],
            "<b>✅ WITHDRAWAL APPROVED</b>\n\n"
            f"Amount: <b>{fmt(w['amount'])} TON</b>\n"
            "Admin is processing your payout.\n\n"
            "Please wait for your funds to arrive."
        )

    elif action == "reject":
        w["status"] = "rejected"
        u["withdrawal_id"] = None

        await bot.send_message(
            u["id"],
            "<b>❌ WITHDRAWAL REJECTED</b>\n\n"
            "Your request was rejected by admin."
        )

    elif action == "paid":
        w["status"] = "paid"
        u["withdrawal_id"] = None
        u["balance"] = max(0.0, float(u["balance"]) - float(w["amount"]))

        await bot.send_message(
            u["id"],
            "<b>💎 PAYMENT COMPLETED</b>\n\n"
            f"Amount: <b>{fmt(w['amount'])} TON</b>\n\n"
            "The admin marked your payout as completed."
        )

    save_db()
    await c.message.edit_reply_markup(reply_markup=None)
    await c.answer("Withdrawal updated.")

# ============================================================
# HISTORY / PROFILE
# ============================================================
@dp.callback_query(F.data == "history")
async def history_callback(c: CallbackQuery):
    tx = [
        x for x in db["transactions"]
        if x["user_id"] == c.from_user.id
    ][-12:]

    body = "\n".join(
        f"• {x['type'].upper()} — <b>{fmt(x.get('amount', 0))} TON</b>"
        for x in reversed(tx)
    ) or "No transactions yet."

    await c.message.edit_text(
        f"<b>📜 TRANSACTION HISTORY</b>\n\n{body}",
        reply_markup=back_keyboard()
    )
    await c.answer()

@dp.callback_query(F.data == "profile")
async def profile_callback(c: CallbackQuery):
    u = get_user(c.from_user.id)
    m = machine(u["machine_id"]) or machine("free")

    await c.message.edit_text(
        "<b>📊 MINER PROFILE</b>\n\n"
        f"User ID: <code>{u['id']}</code>\n"
        f"Balance: <b>{fmt(u['balance'])} TON</b>\n"
        f"Ready to collect: <b>{fmt(u['uncollected'])} TON</b>\n"
        f"Valid referrals: <b>{len(u['valid_referrals'])}</b>\n"
        f"Machine: <b>{m['name']}</b>\n"
        f"Wallet: <b>{'CONNECTED ✅' if u['wallet'] else 'NOT CONNECTED ❌'}</b>",
        reply_markup=back_keyboard()
    )
    await c.answer()

# ============================================================
# ADMIN
# ============================================================
@dp.message(Command("admin"))
async def admin_command(message: Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("⛔ Admin only.")
        return

    await message.answer(
        "<b>⚙️ TON MINER ADMIN CENTER</b>\n\n"
        "Manage channels, earn tasks, machines, settings, withdrawals and broadcast.",
        reply_markup=admin_keyboard()
    )

@dp.callback_query(F.data.startswith("adm:"))
async def admin_panel(c: CallbackQuery):
    if c.from_user.id != ADMIN_ID:
        await c.answer("Admin only.", show_alert=True)
        return

    action = c.data.split(":", 1)[1]

    if action == "stats":
        await c.message.edit_text(
            "<b>📊 SYSTEM STATS</b>\n\n"
            f"Users: <b>{len(db['users'])}</b>\n"
            f"Pending withdrawals: <b>{sum(x['status'] in ('pending','approved') for x in db['withdrawals'].values())}</b>\n"
            f"Required channels: <b>{len(db['settings']['required_channels'])}</b>\n"
            f"Earn tasks: <b>{len(db['earn_tasks'])}</b>\n"
            f"Machines: <b>{len(db['machines'])}</b>\n"
            f"Minimum withdrawal: <b>{fmt(db['settings']['minimum_withdrawal'])} TON</b>\n"
            f"Referral requirement: <b>{db['settings']['required_referrals']}</b>\n"
            f"Machine gate: <b>{'ON' if db['settings']['machine_required_for_withdrawal'] else 'OFF'}</b>",
            reply_markup=admin_keyboard()
        )

    elif action == "withdrawals":
        pending = [
            w for w in db["withdrawals"].values()
            if w["status"] in ("pending", "approved")
        ]

        if not pending:
            body = "No active withdrawals."
        else:
            body = "\n\n".join(
                f"ID: <code>{w['id']}</code>\n"
                f"User: <code>{w['user_id']}</code>\n"
                f"Amount: <b>{fmt(w['amount'])} TON</b>\n"
                f"Status: <b>{w['status'].upper()}</b>\n"
                f"Wallet: <code>{w['wallet']}</code>"
                for w in pending[:10]
            )

        await c.message.edit_text(
            f"<b>💸 WITHDRAWAL QUEUE</b>\n\n{body}",
            reply_markup=admin_keyboard()
        )

    elif action == "channels":
        body = "\n".join(
            f"• <code>{x['chat_id']}</code> — {x['name']}"
            for x in db["settings"]["required_channels"]
        ) or "No required channels."

        await c.message.edit_text(
            "<b>📢 REQUIRED START CHANNELS</b>\n\n"
            f"{body}\n\n"
            "<code>/addchannel @channel | Name</code>\n"
            "<code>/delchannel @channel_or_id</code>",
            reply_markup=admin_keyboard()
        )

    elif action == "tasks":
        body = "\n".join(
            f"• <code>{x['id']}</code> — {x['name']} — +{fmt(x['reward'])} TON"
            for x in db["earn_tasks"]
        ) or "No earn tasks."

        await c.message.edit_text(
            "<b>🎯 EARN TASKS</b>\n\n"
            f"{body}\n\n"
            "<code>/addearn @channel | Name | 0.10</code>\n"
            "<code>/delearntask TASK_ID</code>",
            reply_markup=admin_keyboard()
        )

    elif action == "machines":
        body = "\n".join(
            f"• <code>{x['id']}</code> — {x['name']} — "
            f"{x['stars']} ⭐ — 1 TON/{x['hours_per_ton']}h"
            for x in db["machines"]
        )

        await c.message.edit_text(
            "<b>🖥️ MACHINE CONTROL</b>\n\n"
            f"{body}\n\n"
            "<code>/addmachine Name | Stars | HoursPerCoin</code>\n"
            "<code>/delmachine ID</code>",
            reply_markup=admin_keyboard()
        )

    elif action == "settings":
        await c.message.edit_text(
            "<b>⚙️ SETTINGS</b>\n\n"
            f"Minimum withdrawal: <b>{fmt(db['settings']['minimum_withdrawal'])} TON</b>\n"
            f"Valid referrals: <b>{db['settings']['required_referrals']}</b>\n"
            f"Machine purchase gate: <b>{'ON' if db['settings']['machine_required_for_withdrawal'] else 'OFF'}</b>\n\n"
            "<code>/setmin 5</code>\n"
            "<code>/setrefs 5</code>\n"
            "<code>/setmachinegate on</code>",
            reply_markup=admin_keyboard()
        )

    elif action == "broadcast":
        broadcast_wait.add(ADMIN_ID)
        await c.message.edit_text(
            "<b>📢 BROADCAST MODE</b>\n\n"
            "Send the broadcast message now.",
            reply_markup=admin_keyboard()
        )

    await c.answer()

# ============================================================
# ADMIN COMMANDS
# ============================================================
@dp.message(Command("setmin"))
async def set_min(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    try:
        value = float((message.text or "").split()[1])
        if value <= 0:
            raise ValueError
        db["settings"]["minimum_withdrawal"] = value
        save_db()
        await message.answer(f"✅ Minimum withdrawal set to <b>{fmt(value)} TON</b>")
    except Exception:
        await message.answer("Usage: /setmin 5")

@dp.message(Command("setrefs"))
async def set_refs(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    try:
        value = int((message.text or "").split()[1])
        if value < 0:
            raise ValueError
        db["settings"]["required_referrals"] = value
        save_db()
        await message.answer(f"✅ Referral requirement: <b>{value}</b>")
    except Exception:
        await message.answer("Usage: /setrefs 5")

@dp.message(Command("setmachinegate"))
async def set_machine_gate(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    args = (message.text or "").split()

    if len(args) != 2 or args[1].lower() not in ("on", "off"):
        await message.answer("Usage: /setmachinegate on")
        return

    db["settings"]["machine_required_for_withdrawal"] = args[1].lower() == "on"
    save_db()

    await message.answer(
        "✅ Machine purchase withdrawal requirement: "
        f"<b>{'ON' if db['settings']['machine_required_for_withdrawal'] else 'OFF'}</b>"
    )

@dp.message(Command("addchannel"))
async def add_channel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)

    if len(raw) < 2 or "|" not in raw[1]:
        await message.answer("Usage: /addchannel @channel | Name")
        return

    target, name = [x.strip() for x in raw[1].split("|", 1)]
    chat_id = int(target) if target.startswith("-100") else target
    url = target if target.startswith("http") else f"https://t.me/{target.lstrip('@')}"

    db["settings"]["required_channels"].append({
        "chat_id": chat_id,
        "name": name,
        "url": url
    })
    save_db()

    await message.answer("✅ Required start channel added.")

@dp.message(Command("delchannel"))
async def delete_channel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)
    if len(raw) < 2:
        return

    target = raw[1].strip()

    before = len(db["settings"]["required_channels"])

    db["settings"]["required_channels"] = [
        x for x in db["settings"]["required_channels"]
        if str(x["chat_id"]) != target
    ]

    save_db()

    await message.answer(
        f"✅ Removed {before - len(db['settings']['required_channels'])} channel(s)."
    )

@dp.message(Command("addearn"))
async def add_earn(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)

    if len(raw) < 2 or raw[1].count("|") < 2:
        await message.answer("Usage: /addearn @channel | Name | 0.10")
        return

    target, name, reward = [x.strip() for x in raw[1].split("|", 2)]

    try:
        reward = float(reward)
        if reward <= 0:
            raise ValueError
    except Exception:
        await message.answer("Invalid reward.")
        return

    chat_id = int(target) if target.startswith("-100") else target
    url = target if target.startswith("http") else f"https://t.me/{target.lstrip('@')}"
    task_id = uuid.uuid4().hex[:6]

    db["earn_tasks"].append({
        "id": task_id,
        "chat_id": chat_id,
        "name": name,
        "url": url,
        "reward": reward
    })
    save_db()

    await message.answer(f"✅ Earn task added. ID: <code>{task_id}</code>")

@dp.message(Command("delearntask"))
async def delete_earn(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)
    if len(raw) < 2:
        return

    task_id = raw[1].strip()
    before = len(db["earn_tasks"])

    db["earn_tasks"] = [
        x for x in db["earn_tasks"] if x["id"] != task_id
    ]
    save_db()

    await message.answer(
        f"✅ Removed {before - len(db['earn_tasks'])} earn task(s)."
    )

@dp.message(Command("addmachine"))
async def add_machine(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)

    if len(raw) < 2 or raw[1].count("|") < 2:
        await message.answer("Usage: /addmachine Name | Stars | HoursPerCoin")
        return

    name, stars, hours = [x.strip() for x in raw[1].split("|", 2)]

    try:
        stars = int(stars)
        hours = float(hours)
        if stars < 0 or hours <= 0:
            raise ValueError
    except Exception:
        await message.answer("Invalid machine values.")
        return

    machine_id = "m" + uuid.uuid4().hex[:6]

    db["machines"].append({
        "id": machine_id,
        "name": name,
        "stars": stars,
        "hours_per_ton": hours
    })
    save_db()

    await message.answer(f"✅ Machine added: <code>{machine_id}</code>")

@dp.message(Command("delmachine"))
async def delete_machine(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    raw = (message.text or "").split(maxsplit=1)
    if len(raw) < 2:
        return

    mid = raw[1].strip()

    if mid == "free":
        await message.answer("❌ Free machine cannot be removed.")
        return

    db["machines"] = [
        x for x in db["machines"] if x["id"] != mid
    ]
    save_db()

    await message.answer("✅ Machine removed.")

@dp.message(Command("broadcast"))
async def broadcast_command(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    parts = (message.text or "").split(maxsplit=1)

    if len(parts) == 2:
        await do_broadcast(parts[1], message)
    else:
        broadcast_wait.add(ADMIN_ID)
        await message.answer("📢 Send the broadcast message now.")

async def do_broadcast(text, admin_message):
    broadcast_wait.discard(ADMIN_ID)

    sent = 0

    for uid in list(db["users"].keys()):
        try:
            await bot.send_message(int(uid), text)
            sent += 1
        except Exception:
            pass

    await admin_message.answer(
        f"📢 <b>BROADCAST COMPLETE</b>\n\nSent to <b>{sent}</b> users."
    )

# ============================================================
# USER TEXT HANDLER
# ============================================================
@dp.message()
async def text_handler(message: Message):
    uid = message.from_user.id

    if uid == ADMIN_ID and uid in broadcast_wait:
        await do_broadcast(message.text or "", message)
        return

    if uid in wallet_wait:
        address = (message.text or "").strip()

        if len(address) < 20 or " " in address:
            await message.answer(
                "❌ Please send a valid TON wallet address only."
            )
            return

        u = get_user(uid)
        u["wallet"] = address
        wallet_wait.discard(uid)

        save_db()

        # Wallet completion can finalize an already verified referral.
        if u["channel_verified"] and u["referrer"]:
            ref = get_user(u["referrer"])

            if uid not in ref["valid_referrals"]:
                ref["valid_referrals"].append(uid)
                save_db()

                try:
                    await bot.send_message(
                        ref["id"],
                        "🎉 <b>REFERRAL VERIFIED</b>\n\n"
                        "Wallet connected — your referral is now valid."
                    )
                except Exception:
                    pass

        await message.answer(
            "<b>👛 WALLET CONNECTED</b>\n\n"
            f"Address: <code>{address}</code>\n\n"
            "Your wallet is now registered.\n"
            "Never send a seed phrase or private key.",
            reply_markup=main_keyboard()
        )
        return

    await message.answer(
        "Use the menu below.",
        reply_markup=main_keyboard()
    )

# ============================================================
# START
# ============================================================
async def main():
    print("⚡ TON MINER BOT ONLINE")
    print("⛏️ Mining: elapsed-time simulation")
    print("⭐ Machine payments: Telegram Stars XTR")
    print("💸 Payouts: admin-controlled real TON transfer")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
